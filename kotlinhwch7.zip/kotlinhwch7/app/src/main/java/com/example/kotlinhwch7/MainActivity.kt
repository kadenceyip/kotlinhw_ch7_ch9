package com.example.kotlinhwch7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.cubee_list.view.*


    data class Item (
        val photo: Int,
        val name: String
    )


    class MyAdapter constructor(private val layout: Int, private val data:
    ArrayList<Item>) : BaseAdapter() {

        override fun getCount() = data.size
        override fun getItem(position: Int) = data[position]
        override fun getItemId(position: Int) = 0L
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

            val view = View.inflate(parent?.context, layout, null)
            view.img_photo.setImageResource(data[position].photo)
            view.tv_name.text = data[position].name

            return view
            }
        }

class MainActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val item = ArrayList<Item>()
        val transNameArray = resources.obtainTypedArray(R.array.transNameArray)

        for(i in 0 until transNameArray.length())
            item.add(Item(transNameArray.getResourceId(i,0),"交通${i+1}"))

                    transNameArray.recycle()
                    spinner.adapter = MyAdapter(R.layout.trans_list, item)


        val cubeeNameArray = resources.obtainTypedArray(R.array.cubeeNameArray)

        for(i in 0 until cubeeNameArray.length())
            item.add(Item(cubeeNameArray.getResourceId(i,0),"表情${i+1}"))
        gridview.numColumns = 3
        gridview.adapter = MyAdapter( R.layout.cubee_list, item)



            listView.adapter = ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,
                arrayListOf("訊息1", "訊息2", "訊息3", "訊息4", "訊息5", "訊息6"))
        }


    }


